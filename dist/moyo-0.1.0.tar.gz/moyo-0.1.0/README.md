# Moyo

Experimental tooling for corpus mapping and barrier probing. Moyo provides comprehensive tools for building knowledge corpora and assessing information barriers between private and public data sources.

## Overview

Moyo is designed to help organizations understand and manage information barriers between their private data and public information sources. It provides tools for:

- **Private Side Processing**: Ingest and index private data into searchable vector corpora
- **Public Side Analysis**: Gather and analyze public information sources
- **Barrier Assessment**: Use LLM-assisted techniques to probe information boundaries
- **Corpus Management**: Build, maintain, and query knowledge corpora

## Architecture

### Components

- **privateside**: Ingest local data and map into FAISS-backed corpus
  - Data input processing and validation
  - Text chunking and embedding
  - Corpus building and management
  - Index creation and optimization

- **publicside**: Gather open-source information and probe barriers between corpora
  - Public source crawling and parsing (`gatherpublicsources/`)
    - Crawler orchestrator accepts topic strings or a list of tokens to drive multi-source searches
    - Source adapters for patents, press releases, git commits, conference talks, leaked code, generic web search
    - Parsers and enrichers (HTML/PDF parsing, classification, deduplication), scoring and filtering
  - Barrier probing (`barrierprobe/`)
    - Distance-based analysis between private/public indices; clustering and nearest-neighbor links
    - Iterative LLM-assisted probing (planned) to test barrier integrity
  - Semantic similarity analysis
  - Information leakage detection

## Installation

### Prerequisites

Moyo depends on the `shared-utils` package. Make sure to install it first:

```bash
cd shared_utils
pip install -e .
```

### Installing Moyo

#### Development Mode

```bash
cd moyo
pip install -e .
```

#### Building Package

```bash
cd moyo
pip install build
python -m build
```

This creates distribution files in the `dist/` directory.

#### Installing from Built Package

```bash
cd moyo
pip install dist/moyo-0.1.0-py3-none-any.whl
```

## Quick Start

### 1. Initial Setup

```bash
# Install dependencies
cd shared_utils && pip install -e .
cd ../moyo && pip install -e .

# Set up directory structure
moyo setup

# Check system status
moyo info
```

### 2. Process Private Data

```bash
# Process text directly
moyo-datainput process "Your confidential text here"

# Process files
moyo-datainput process --file document.txt
moyo-datainput process --files file1.txt file2.txt

# Custom configuration
moyo-datainput process --chunk-size 256 --chunk-overlap 25 --model all-MiniLM-L6-v2
```

### 3. Build Corpora

```bash
# Build from directory
moyo-corpus build /path/to/documents

# Build from text inputs
moyo-corpus build-text "Text 1" "Text 2" "Text 3"

# With custom settings
moyo-corpus build --chunk-size 512 --dedupe --normalize
```

### 4. Analyze Barriers

```bash
# LLM-assisted fuzzing
moyo-probe fuzz -p "data breach" -t "confidential information" -i corpus.index

# Search corpora
moyo-probe search -c corpus_dir -q "security incident" -k 10

# Test LLM connectivity
moyo-probe test-llm --llm-provider openai --model gpt-4
```

## Command Line Interface

### Main Commands

```bash
# Main moyo command with enhanced help
moyo --help
moyo info          # System information
moyo setup         # Initial setup
moyo version       # Version information

# Data input utilities
moyo-datainput --help
moyo-datainput process --help

# Corpus building
moyo-corpus --help
moyo-corpus build --help
moyo-corpus build-text --help

# Barrier probing with LLM fuzzing
moyo-probe --help
moyo-probe fuzz --help
moyo-probe search --help
moyo-probe test-llm --help
```

### Advanced Examples

```bash
# Process multiple files with custom settings
moyo-datainput process --files doc1.txt doc2.txt doc3.txt \
  --chunk-size 256 \
  --chunk-overlap 50 \
  --model all-MiniLM-L6-v2 \
  --index-type hnsw \
  --output-dir indexes/custom

# Build corpus with deduplication
moyo-corpus build /path/to/documents \
  --chunk-size 512 \
  --dedupe \
  --normalize \
  --save-chunks \
  --output-dir indexes/private

# LLM-assisted fuzzing with custom parameters
moyo-probe fuzz \
  -p "data breach" "security incident" \
  -t "confidential information disclosure" \
  -i corpus.index \
  --llm-provider openai \
  --model gpt-4 \
  --max-iterations 10 \
  --target-similarity 0.95 \
  --verbose
```

### Python API

```python
from moyo.privateside.mapcorpus import CorpusBuilder
from moyo.publicside.barrierprobe import BarrierAnalyzer

# Build corpus from private data
builder = CorpusBuilder()
builder.add_text("Your private text here")
index = builder.build_index()

# Analyze barriers
analyzer = BarrierAnalyzer()
results = analyzer.analyze_barriers(private_index=index)
```

### Public Side: Token-driven crawling

```python
from pathlib import Path
from moyo.privateside.mapcorpus import tokens_for_corpus
from moyo.publicside.gatherpublicsources.crawler import PublicSourcesCrawler

# Derive topic tokens from private corpus
centroids, topic_tokens, labels, texts = tokens_for_corpus(Path('moyo/data/private/corpus.txt'), top_k=8)
tokens = [t for cluster in topic_tokens for t in cluster][:25]

# Crawl public sources guided by tokens
crawler = PublicSourcesCrawler()
result = crawler.crawl_with_tokens(tokens)
print(result.message)
```

## Configuration

### Environment Variables

```bash
# LLM API Keys
export OPENAI_API_KEY="your-openai-api-key"
export ANTHROPIC_API_KEY="your-anthropic-api-key"

# Optional: Custom model configurations
export MOYO_EMBEDDING_MODEL="all-MiniLM-L6-v2"
export MOYO_CHUNK_SIZE="512"
export MOYO_CHUNK_OVERLAP="50"
```

### Directory Structure

After running `moyo setup`, the following structure is created:

```
.
├── indexes/
│   ├── private/     # Private corpus indexes
│   └── public/      # Public corpus indexes
├── data/
│   ├── private/     # Private data files
│   └── public/      # Public data files
└── logs/            # Application logs
```

## Dependencies

### Core Dependencies
- `shared-utils`: Shared utilities for text processing, embeddings, and indexing
- `pydantic`: Data validation and settings management
- `faiss-gpu / faiss-cpu`: Vector similarity search
- `click`: Command line interface

### LLM Dependencies
- `openai>=1.0.0`: OpenAI API client for LLM fuzzing
- `anthropic>=0.7.0`: Anthropic API client for LLM fuzzing

### Optional Dependencies
- `sentence-transformers`: For advanced embedding models
- `pyahocorasick`: For optimized pattern matching

## Features

### 🔍 **Text Processing**
- Configurable chunking with overlap
- Text normalization and cleaning
- Deduplication and similarity detection
- Support for multiple file formats

### 🧠 **Embedding & Indexing**
- Multiple embedding models (all-MiniLM-L6-v2, etc.)
- FAISS index types (flat, IVF, HNSW)
- Vector similarity search
- Index optimization and persistence

### 🤖 **LLM Integration**
- OpenAI GPT models support
- Anthropic Claude models support
- LLM-assisted phrase fuzzing
- Semantic transformation and refinement

### 📊 **Analysis Tools**
- Barrier probing between corpora
- Information leakage detection
- Similarity analysis and scoring
- Corpus comparison and evaluation

## Development

### Project Structure

```
moyo/
├── moyo/
│   ├── __main__.py               # Entry point
│   ├── cli.py                    # Main CLI interface
│   ├── config/                   # Configuration management
│   ├── interfaces/               # Common interfaces
│   ├── privateside/              # Private data processing
│   │   ├── datainput/            # Data input and validation
│   │   └── mapcorpus/            # Corpus building & centroids
│   │       ├── centroids.py      # Centroid and topic token helpers
│   │       ├── builder.py        # Corpus builder and FAISS indexer
│   │       └── schema.py         # Pydantic schemas
│   └── publicside/               # Public data analysis
│       ├── barrierprobe/         # Barrier analysis tools
│       └── gatherpublicsources/  # Public source gathering
│           ├── crawler.py        # Orchestrator with crawl() and crawl_with_tokens()
│           ├── schema.py         # Pydantic schemas
│           ├── parsers/          # HTML/PDF/text parsers
│           ├── enrichers/        # Classification/dedupe enrichers
│           └── sources/          # Source adapters
├── examples/                     # Usage examples
├── tests/                        # Test suite
└── docs/                         # Documentation
```

### Contributing

1. **Install in development mode**:
   ```bash
   cd moyo && pip install -e .
   ```

2. **Run tests**:
   ```bash
   python -m pytest tests/
   ```

3. **Check code quality**:
   ```bash
   flake8 moyo/
   black moyo/
   ```

### Roadmap

- [ ] Enhanced public source gathering
- [ ] Advanced barrier analysis algorithms
- [ ] Web-based dashboard
- [ ] Real-time monitoring capabilities
- [ ] Integration with external data sources
- [ ] Performance optimization for large corpora
