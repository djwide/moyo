from pydantic import BaseSettings


class Settings(BaseSettings):
    """Application settings."""

    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    data_dir: str = "data"
    index_dir: str = "indexes"


settings = Settings()
