"""LLM-assisted fuzzing for barrier probing.

This module provides functionality to use LLMs (defaulting to OpenAI) to assist in fuzzing
by finding semantically close phrases and using the LLM to reduce semantic distance.
"""

import logging
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import json
import time

from shared_utils import (
    embed,
    FAISSIndex,
    normalize_text,
    TextNormalizationConfig,
    get_logger
)

logger = get_logger(__name__)


@dataclass
class LLMFuzzerConfig:
    """Configuration for LLM-assisted fuzzing."""
    
    # LLM Configuration
    llm_provider: str = "openai"  # "openai", "anthropic", "local"
    model_name: str = "gpt-4"  # Default to OpenAI's large model
    api_key: Optional[str] = None
    max_tokens: int = 500
    temperature: float = 0.7
    
    # Semantic Search Configuration
    search_k: int = 10  # Number of closest phrases to retrieve
    similarity_threshold: float = 0.8  # Minimum similarity to consider
    
    # Fuzzing Configuration
    max_iterations: int = 5  # Maximum fuzzing iterations
    target_similarity: float = 0.95  # Target similarity to achieve
    prompt_template: str = """
You are an expert at semantic analysis and text transformation. Your task is to modify the given phrase to make it semantically closer to the target concept while maintaining its core meaning.

Target concept: {target_concept}

Original phrase: {original_phrase}

Similar phrases from the corpus:
{similar_phrases}

Instructions:
1. Analyze the semantic relationship between the original phrase and target concept
2. Study the similar phrases to understand the semantic patterns
3. Transform the original phrase to reduce semantic distance to the target
4. Maintain the original meaning while making it more semantically aligned
5. Return only the transformed phrase, no explanations

Transformed phrase:"""


class LLMFuzzer:
    """LLM-assisted fuzzer for semantic barrier probing."""
    
    def __init__(self, config: Optional[LLMFuzzerConfig] = None):
        """Initialize the LLM fuzzer.
        
        Args:
            config: Configuration for the fuzzer
        """
        self.config = config or LLMFuzzerConfig()
        self.normalization_config = TextNormalizationConfig(
            lowercase=True,
            normalize_unicode=True,
            normalize_whitespace=True,
            remove_urls=True,
            remove_emails=True,
            normalize_punctuation=True
        )
        
        # Initialize LLM client
        self.llm_client = self._initialize_llm_client()
        self.interaction_log: List[Dict[str, str]] = []
        
    def _initialize_llm_client(self):
        """Initialize the LLM client based on configuration."""
        if self.config.llm_provider == "openai":
            try:
                import openai
                if self.config.api_key:
                    openai.api_key = self.config.api_key
                return openai
            except ImportError:
                logger.error("OpenAI library not installed. Install with: pip install openai")
                return None
        elif self.config.llm_provider == "anthropic":
            try:
                import anthropic
                return anthropic.Client(api_key=self.config.api_key)
            except ImportError:
                logger.error("Anthropic library not installed. Install with: pip install anthropic")
                return None
        else:
            logger.error(f"Unsupported LLM provider: {self.config.llm_provider}")
            return None
    
    def query_llm(self, prompt: str) -> Optional[str]:
        """Query the LLM with the given prompt.
        
        Args:
            prompt: The prompt to send to the LLM
            
        Returns:
            The LLM response or None if failed
        """
        if not self.llm_client:
            logger.error("LLM client not initialized")
            return None
            
        try:
            if self.config.llm_provider == "openai":
                response = self.llm_client.ChatCompletion.create(
                    model=self.config.model_name,
                    messages=[
                        {"role": "system", "content": "You are a helpful assistant for semantic text transformation."},
                        {"role": "user", "content": prompt}
                    ],
                    max_tokens=self.config.max_tokens,
                    temperature=self.config.temperature
                )
                text = response.choices[0].message.content.strip()
            elif self.config.llm_provider == "anthropic":
                response = self.llm_client.messages.create(
                    model=self.config.model_name,
                    max_tokens=self.config.max_tokens,
                    temperature=self.config.temperature,
                    messages=[
                        {"role": "user", "content": prompt}
                    ]
                )
                text = response.content[0].text.strip()
            else:
                return None

            self.interaction_log.append({"prompt": prompt, "response": text})
            return text

        except Exception as e:
            logger.error(f"Error querying LLM: {e}")
            return None
    
    def find_similar_phrases(self, 
                           query: str, 
                           index: FAISSIndex, 
                           k: Optional[int] = None) -> List[Dict[str, Any]]:
        """Find semantically similar phrases in the index.
        
        Args:
            query: Query phrase to find similar phrases for
            index: FAISS index containing the corpus
            k: Number of results to return (defaults to config.search_k)
            
        Returns:
            List of similar phrases with metadata
        """
        if k is None:
            k = self.config.search_k
            
        # Normalize query
        normalized_query = normalize_text(query, self.normalization_config)
        
        # Generate query embedding
        query_embeddings = embed([normalized_query])
        if not query_embeddings:
            logger.error("Failed to generate query embedding")
            return []
        
        # Search index
        distances, indices, metadata = index.search(query_embeddings[0], k=k)
        
        # Filter by similarity threshold
        results = []
        for i, (distance, idx, meta) in enumerate(zip(distances, indices, metadata)):
            if distance >= self.config.similarity_threshold:
                results.append({
                    "rank": i + 1,
                    "similarity": distance,
                    "index": idx,
                    "metadata": meta,
                    "text": meta.get("text", "")
                })
        
        return results
    
    def create_fuzzing_prompt(self, 
                            target_concept: str,
                            original_phrase: str,
                            similar_phrases: List[Dict[str, Any]]) -> str:
        """Create a prompt for LLM-assisted fuzzing.
        
        Args:
            target_concept: The target concept to move towards
            original_phrase: The original phrase to transform
            similar_phrases: List of similar phrases from the corpus
            
        Returns:
            Formatted prompt for the LLM
        """
        # Format similar phrases
        phrases_text = ""
        for i, phrase_info in enumerate(similar_phrases[:5]):  # Top 5 phrases
            phrases_text += f"{i+1}. {phrase_info['text']} (similarity: {phrase_info['similarity']:.3f})\n"
        
        # Create prompt using template
        prompt = self.config.prompt_template.format(
            target_concept=target_concept,
            original_phrase=original_phrase,
            similar_phrases=phrases_text
        )
        
        return prompt
    
    def fuzz_phrase(self,
                   original_phrase: str,
                   target_concept: str,
                   index: FAISSIndex) -> Tuple[str, float, List[str], List[Dict[str, str]]]:
        """Fuzz a phrase to reduce semantic distance to target concept.
        
        Args:
            original_phrase: The original phrase to fuzz
            target_concept: The target concept to move towards
            index: FAISS index for semantic search
            
        Returns:
            Tuple of (fuzzed_phrase, final_similarity, transformation_history)
        """
        current_phrase = original_phrase
        transformation_history = [original_phrase]
        interactions: List[Dict[str, str]] = []
        
        logger.info(f"Starting fuzzing for phrase: '{original_phrase}'")
        logger.info(f"Target concept: '{target_concept}'")
        
        for iteration in range(self.config.max_iterations):
            logger.info(f"Fuzzing iteration {iteration + 1}/{self.config.max_iterations}")
            
            # Find similar phrases
            similar_phrases = self.find_similar_phrases(current_phrase, index)
            
            if not similar_phrases:
                logger.warning("No similar phrases found, stopping fuzzing")
                break
            
            # Create fuzzing prompt
            prompt = self.create_fuzzing_prompt(target_concept, current_phrase, similar_phrases)

            # Query LLM
            fuzzed_phrase = self.query_llm(prompt)
            
            if not fuzzed_phrase:
                logger.warning("LLM query failed, stopping fuzzing")
                break

            interactions.append({"prompt": prompt, "response": fuzzed_phrase})
            
            # Normalize the fuzzed phrase
            fuzzed_phrase = normalize_text(fuzzed_phrase, self.normalization_config)
            
            # Check if we've achieved target similarity
            fuzzed_embeddings = embed([fuzzed_phrase])
            if fuzzed_embeddings:
                # Calculate similarity to target concept
                target_embeddings = embed([target_concept])
                if target_embeddings:
                    # Simple cosine similarity (assuming normalized embeddings)
                    similarity = sum(a * b for a, b in zip(fuzzed_embeddings[0], target_embeddings[0]))
                    
                    logger.info(f"Iteration {iteration + 1}: similarity = {similarity:.3f}")
                    
                    if similarity >= self.config.target_similarity:
                        logger.info(f"Target similarity achieved: {similarity:.3f}")
                        transformation_history.append(fuzzed_phrase)
                        return fuzzed_phrase, similarity, transformation_history, interactions
                    
                    current_phrase = fuzzed_phrase
                    transformation_history.append(fuzzed_phrase)
                else:
                    logger.warning("Failed to generate target embedding")
                    break
            else:
                logger.warning("Failed to generate fuzzed phrase embedding")
                break
            
            # Rate limiting
            time.sleep(1)
        
        # Return the best result we achieved
        if transformation_history:
            final_phrase = transformation_history[-1]
            final_embeddings = embed([final_phrase])
            target_embeddings = embed([target_concept])
            
            if final_embeddings and target_embeddings:
                final_similarity = sum(a * b for a, b in zip(final_embeddings[0], target_embeddings[0]))
                return final_phrase, final_similarity, transformation_history, interactions

        return original_phrase, 0.0, transformation_history, interactions
    
    def batch_fuzz_phrases(self,
                          phrases: List[str],
                          target_concept: str,
                          index: FAISSIndex,
                          analyzer: Optional[Any] = None,
                          analysis_top_k: int = 5) -> List[Dict[str, Any]]:
        """Fuzz multiple phrases in batch.
        
        Args:
            phrases: List of phrases to fuzz
            target_concept: The target concept to move towards
            index: FAISS index for semantic search
            
        Returns:
            List of fuzzing results for each phrase
        """
        results = []
        
        for i, phrase in enumerate(phrases):
            logger.info(f"Fuzzing phrase {i+1}/{len(phrases)}: '{phrase}'")
            
            fuzzed_phrase, similarity, history, interactions = self.fuzz_phrase(phrase, target_concept, index)

            analysis = None
            if analyzer is not None:
                try:
                    analysis = analyzer.search_phrase(fuzzed_phrase, top_k=analysis_top_k)
                except Exception as e:
                    logger.warning(f"Analysis failed for phrase '{fuzzed_phrase}': {e}")

            results.append({
                "original_phrase": phrase,
                "fuzzed_phrase": fuzzed_phrase,
                "final_similarity": similarity,
                "transformation_history": history,
                "iterations": len(history) - 1,
                "target_concept": target_concept,
                "prompt_response_log": interactions,
                "analysis": analysis,
            })
            
            # Rate limiting between phrases
            time.sleep(2)
        
        return results


def create_fuzzer_from_config(config_dict: Dict[str, Any]) -> LLMFuzzer:
    """Create an LLM fuzzer from a configuration dictionary.
    
    Args:
        config_dict: Configuration dictionary
        
    Returns:
        Configured LLMFuzzer instance
    """
    config = LLMFuzzerConfig(**config_dict)
    return LLMFuzzer(config)


def fuzz_phrases_for_barrier_analysis(phrases: List[str],
                                    target_concept: str,
                                    index: FAISSIndex,
                                    config: Optional[LLMFuzzerConfig] = None,
                                    analyzer: Optional[Any] = None,
                                    analysis_top_k: int = 5) -> List[Dict[str, Any]]:
    """Convenience function for fuzzing phrases for barrier analysis.
    
    Args:
        phrases: List of phrases to fuzz
        target_concept: The target concept to move towards
        index: FAISS index for semantic search
        config: Optional fuzzer configuration
        
    Returns:
        List of fuzzing results
    """
    fuzzer = LLMFuzzer(config)
    return fuzzer.batch_fuzz_phrases(phrases, target_concept, index, analyzer=analyzer, analysis_top_k=analysis_top_k)
