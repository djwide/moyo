"""Barrier analyzer for comparing public and private FAISS indexes."""

import time
import logging
import numpy as np
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path
import json

from .schema import BarrierProbeConfig, BarrierProbeResult
from .public_index_builder import load_public_index
from moyo.privateside.mapcorpus.builder import CorpusBuilder
from shared_utils import generate_id, embed

logger = logging.getLogger(__name__)


class BarrierAnalyzer:
    """Analyzer for comparing public and private information barriers."""
    
    def __init__(self, config: BarrierProbeConfig):
        """Initialize the barrier analyzer.
        
        Args:
            config: Barrier probe configuration
        """
        self.config = config
        self.public_builder: Optional[Any] = None
        self.private_builder: Optional[CorpusBuilder] = None

    def _filter_results(self, matches: List[Dict[str, Any]], top_k: int) -> List[Dict[str, Any]]:
        """Filter matches based on similarity threshold and return top results.

        Args:
            matches: List of match dictionaries including a ``distance`` field.
            top_k: Maximum number of results to return after filtering.

        Returns:
            Filtered list of matches sorted by distance.
        """
        if not matches:
            return []

        filtered = [m for m in matches if m.get("distance") is not None and m["distance"] <= self.config.similarity_threshold]
        filtered.sort(key=lambda x: x["distance"])
        return filtered[:top_k]
        
    def load_indexes(self) -> bool:
        """Load both public and private indexes.
        
        Returns:
            True if both indexes loaded successfully
        """
        try:
            # Load public index
            logger.info(f"Loading public index from {self.config.public_index_path}")
            self.public_builder = load_public_index(self.config.public_index_path)
            if not self.public_builder:
                logger.error(f"Failed to load public index from {self.config.public_index_path}")
                return False
            
            # Load private index
            logger.info(f"Loading private index from {self.config.private_index_path}")
            self.private_builder = CorpusBuilder.load_from_path(self.config.private_index_path)
            if not self.private_builder:
                logger.error(f"Failed to load private index from {self.config.private_index_path}")
                return False
            
            logger.info("Both indexes loaded successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error loading indexes: {e}")
            return False
    
    def calculate_cosine_distance(self, vec1: List[float], vec2: List[float]) -> float:
        """Calculate cosine distance between two vectors.
        
        Args:
            vec1: First vector
            vec2: Second vector
            
        Returns:
            Cosine distance (1 - cosine similarity)
        """
        vec1 = np.array(vec1, dtype=np.float32)
        vec2 = np.array(vec2, dtype=np.float32)
        
        # Normalize vectors
        norm1 = np.linalg.norm(vec1)
        norm2 = np.linalg.norm(vec2)
        
        if norm1 == 0 or norm2 == 0:
            return 1.0
        
        vec1_normalized = vec1 / norm1
        vec2_normalized = vec2 / norm2
        
        # Calculate cosine similarity
        cosine_similarity = np.dot(vec1_normalized, vec2_normalized)
        
        # Return cosine distance (1 - similarity)
        return 1.0 - cosine_similarity
    
    def calculate_sobolev_norm(self, vec: List[float], order: int = 1) -> float:
        """Calculate Sobolev norm of a vector.
        
        Args:
            vec: Input vector
            order: Order of the Sobolev norm (default: 1)
            
        Returns:
            Sobolev norm value
        """
        vec = np.array(vec, dtype=np.float32)
        
        if order == 1:
            # First-order Sobolev norm: ||f||_H^1 = sqrt(||f||_L^2^2 + ||∇f||_L^2^2)
            # For discrete vectors, we approximate ∇f as finite differences
            l2_norm = np.linalg.norm(vec)
            
            # Calculate gradient (finite differences)
            if len(vec) > 1:
                gradient = np.diff(vec)
                gradient_norm = np.linalg.norm(gradient)
            else:
                gradient_norm = 0.0
            
            return np.sqrt(l2_norm**2 + gradient_norm**2)
        
        elif order == 2:
            # Second-order Sobolev norm
            l2_norm = np.linalg.norm(vec)
            
            if len(vec) > 2:
                # Second derivative (finite differences)
                second_deriv = np.diff(vec, n=2)
                second_deriv_norm = np.linalg.norm(second_deriv)
            else:
                second_deriv_norm = 0.0
            
            return np.sqrt(l2_norm**2 + second_deriv_norm**2)
        
        else:
            # For other orders, use L2 norm as approximation
            return np.linalg.norm(vec)
    
    def find_closest_matches(self, top_k: int = 10) -> List[Dict[str, Any]]:
        """Find the closest matches between public and private chunks.
        
        Args:
            top_k: Number of closest matches to return
            
        Returns:
            List of closest matches with distances
        """
        if not self.public_builder or not self.private_builder:
            logger.error("Indexes not loaded")
            return []
        
        logger.info("Finding closest matches between public and private chunks...")
        
        # Get embeddings from both indexes
        public_embeddings = []
        public_chunks = []
        
        for chunk in self.public_builder.chunks:
            if chunk.embedding:
                public_embeddings.append(chunk.embedding)
                public_chunks.append(chunk)
        
        private_embeddings = []
        private_chunks = []
        
        for chunk in self.private_builder.chunks:
            if chunk.embedding:
                private_embeddings.append(chunk.embedding)
                private_chunks.append(chunk)
        
        if not public_embeddings or not private_embeddings:
            logger.warning("No embeddings found in one or both indexes")
            return []
        
        # Calculate all pairwise distances
        distances = []
        
        for i, pub_emb in enumerate(public_embeddings):
            for j, priv_emb in enumerate(private_embeddings):
                distance = self.calculate_cosine_distance(pub_emb, priv_emb)
                distances.append({
                    'distance': distance,
                    'public_chunk': public_chunks[i],
                    'private_chunk': private_chunks[j],
                    'public_index': i,
                    'private_index': j
                })
        
        # Sort by distance and return top_k
        distances.sort(key=lambda x: x['distance'])
        
        results = []
        for i, match in enumerate(distances[:top_k]):
            result = {
                'rank': i + 1,
                'distance': match['distance'],
                'public_chunk_id': match['public_chunk'].id,
                'public_content': match['public_chunk'].content[:200] + "..." if len(match['public_chunk'].content) > 200 else match['public_chunk'].content,
                'public_source_type': match['public_chunk'].source_type.value,
                'public_metadata': match['public_chunk'].metadata,
                'private_chunk_id': match['private_chunk'].id,
                'private_content': match['private_chunk'].content[:200] + "..." if len(match['private_chunk'].content) > 200 else match['private_chunk'].content,
                'private_metadata': match['private_chunk'].metadata
            }
            results.append(result)
        
        logger.info(f"Found {len(results)} closest matches")
        return results

    def search_phrase(self, phrase: str, top_k: int = 5) -> Dict[str, List[Dict[str, Any]]]:
        """Search indexes for chunks similar to the provided phrase.

        Args:
            phrase: Text to embed and compare against indexes.
            top_k: Number of results to return for each index.

        Returns:
            Dictionary with ``public`` and ``private`` match lists.
        """
        if not self.public_builder or not self.private_builder:
            logger.error("Indexes not loaded")
            return {}

        try:
            query_emb = embed([phrase])[0]
        except Exception as e:
            logger.error(f"Failed to embed phrase: {e}")
            return {}

        results = {"public": [], "private": []}

        for chunk in self.public_builder.chunks:
            if chunk.embedding:
                dist = self.calculate_cosine_distance(query_emb, chunk.embedding)
                results["public"].append({
                    "distance": dist,
                    "chunk_id": chunk.id,
                    "content": chunk.content[:200] + "..." if len(chunk.content) > 200 else chunk.content,
                    "source_type": chunk.source_type.value,
                    "metadata": chunk.metadata,
                })

        for chunk in self.private_builder.chunks:
            if chunk.embedding:
                dist = self.calculate_cosine_distance(query_emb, chunk.embedding)
                results["private"].append({
                    "distance": dist,
                    "chunk_id": chunk.id,
                    "content": chunk.content[:200] + "..." if len(chunk.content) > 200 else chunk.content,
                    "metadata": chunk.metadata,
                })

        results["public"].sort(key=lambda x: x["distance"])
        results["private"].sort(key=lambda x: x["distance"])

        results["public"] = results["public"][:top_k]
        results["private"] = results["private"][:top_k]

        return results
    
    def find_largest_sobolev_norms(self, top_k: int = 10, order: int = 1) -> List[Dict[str, Any]]:
        """Find chunks with the largest Sobolev norms.
        
        Args:
            top_k: Number of largest norms to return
            order: Order of Sobolev norm to calculate
            
        Returns:
            List of chunks with largest Sobolev norms
        """
        if not self.public_builder or not self.private_builder:
            logger.error("Indexes not loaded")
            return []
        
        logger.info(f"Finding chunks with largest Sobolev norms (order {order})...")
        
        # Calculate Sobolev norms for all chunks
        public_norms = []
        private_norms = []
        
        # Public chunks
        for chunk in self.public_builder.chunks:
            if chunk.embedding:
                norm = self.calculate_sobolev_norm(chunk.embedding, order)
                public_norms.append({
                    'norm': norm,
                    'chunk': chunk,
                    'type': 'public'
                })
        
        # Private chunks
        for chunk in self.private_builder.chunks:
            if chunk.embedding:
                norm = self.calculate_sobolev_norm(chunk.embedding, order)
                private_norms.append({
                    'norm': norm,
                    'chunk': chunk,
                    'type': 'private'
                })
        
        # Combine and sort by norm
        all_norms = public_norms + private_norms
        all_norms.sort(key=lambda x: x['norm'], reverse=True)
        
        # Return top_k
        results = []
        for i, norm_info in enumerate(all_norms[:top_k]):
            chunk = norm_info['chunk']
            result = {
                'rank': i + 1,
                'norm': norm_info['norm'],
                'type': norm_info['type'],
                'chunk_id': chunk.id,
                'content': chunk.content[:200] + "..." if len(chunk.content) > 200 else chunk.content,
                'metadata': chunk.metadata
            }
            
            if norm_info['type'] == 'public':
                result['source_type'] = chunk.source_type.value
            else:
                result['source_type'] = 'private'
            
            results.append(result)
        
        logger.info(f"Found {len(results)} chunks with largest Sobolev norms")
        return results
    
    def analyze_barriers(self, top_k: int = 10) -> BarrierProbeResult:
        """Perform comprehensive barrier analysis.
        
        Args:
            top_k: Number of top results to return for each analysis
            
        Returns:
            BarrierProbeResult with analysis results
        """
        start_time = time.time()
        
        # Load indexes
        if not self.load_indexes():
            return BarrierProbeResult(
                probe_id=generate_id("probe"),
                public_index_info={},
                private_index_info={},
                similarity_threshold=self.config.similarity_threshold,
                message="Failed to load indexes"
            )
        
        # Get index information
        public_index_info = {
            'chunk_count': len(self.public_builder.chunks),
            'source_types': list(set(chunk.source_type.value for chunk in self.public_builder.chunks)),
            'organizations': list(set(chunk.metadata.get('source_organization') for chunk in self.public_builder.chunks if chunk.metadata.get('source_organization')))
        }
        
        private_index_info = {
            'chunk_count': len(self.private_builder.chunks),
            'document_count': len(set(chunk.document_id for chunk in self.private_builder.chunks))
        }
        
        # Find closest matches and filter potential breaches
        raw_matches = self.find_closest_matches(top_k * 5)
        filtered_matches = self._filter_results(raw_matches, top_k)

        # Find largest Sobolev norms
        largest_norms = self.find_largest_sobolev_norms(top_k)

        # Identify potential breaches
        potential_breaches = []
        breach_count = len(filtered_matches)
        high_risk = 0
        medium_risk = 0
        low_risk = 0

        for match in filtered_matches:
            # Determine risk level based on distance
            if match['distance'] <= 0.1:
                risk_level = "high"
                high_risk += 1
            elif match['distance'] <= 0.3:
                risk_level = "medium"
                medium_risk += 1
            else:
                risk_level = "low"
                low_risk += 1

            breach_info = {
                'rank': match.get('rank'),
                'type': 'similarity_breach',
                'risk_level': risk_level,
                'distance': match['distance'],
                'public_chunk_id': match['public_chunk_id'],
                'private_chunk_id': match['private_chunk_id'],
                'public_content': match['public_content'],
                'private_content': match['private_content'],
                'public_metadata': match.get('public_metadata', {}),
                'private_metadata': match.get('private_metadata', {}),
                'public_source_type': match.get('public_source_type'),
            }
            potential_breaches.append(breach_info)
        
        # Generate recommendations
        recommendations = []
        
        if breach_count > 0:
            recommendations.append(f"Found {breach_count} potential information barrier breaches")
            recommendations.append(f"High risk breaches: {high_risk}, Medium risk: {medium_risk}, Low risk: {low_risk}")
            
            if high_risk > 0:
                recommendations.append("Immediate action required: Review high-risk breaches")
            
            if medium_risk > 0:
                recommendations.append("Review medium-risk breaches and consider additional controls")
        else:
            recommendations.append("No potential breaches detected above threshold")
        
        if len(raw_matches) > 0:
            avg_distance = sum(match['distance'] for match in raw_matches) / len(raw_matches)
            recommendations.append(f"Average distance between closest matches: {avg_distance:.4f}")
        
        processing_time = time.time() - start_time
        
        return BarrierProbeResult(
            probe_id=generate_id("probe"),
            public_index_info=public_index_info,
            private_index_info=private_index_info,
            similarity_threshold=self.config.similarity_threshold,
            potential_breaches=potential_breaches,
            breach_count=breach_count,
            high_risk_breaches=high_risk,
            medium_risk_breaches=medium_risk,
            low_risk_breaches=low_risk,
            processing_time=processing_time,
            recommendations=recommendations,
            metadata={
                'closest_matches': raw_matches,
                'top_breaches': filtered_matches,
                'largest_sobolev_norms': largest_norms,
                'total_comparisons': len(raw_matches) if raw_matches else 0
            }
        )


def analyze_barriers(
    public_index_path: str,
    private_index_path: str,
    similarity_threshold: float = 0.8,
    top_k: int = 10
) -> BarrierProbeResult:
    """Convenience function to analyze information barriers.
    
    Args:
        public_index_path: Path to public index
        private_index_path: Path to private index
        similarity_threshold: Threshold for breach detection
        top_k: Number of top results to return
        
    Returns:
        BarrierProbeResult with analysis results
    """
    config = BarrierProbeConfig(
        public_index_path=public_index_path,
        private_index_path=private_index_path,
        similarity_threshold=similarity_threshold
    )
    
    analyzer = BarrierAnalyzer(config)
    return analyzer.analyze_barriers(top_k)
