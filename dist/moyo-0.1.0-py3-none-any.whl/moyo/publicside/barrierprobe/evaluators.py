def evaluate(candidate: str) -> float:
    """LLM-based risk or semantic distance scoring (stub)."""
    return 0.0
