"""Adapters to integrate with SenteGuard when available."""

try:
    from SenTeGuard import index_utils
except ImportError:  # pragma: no cover
    index_utils = None


def get_index_utils():
    """Return SenteGuard index utilities if installed."""
    return index_utils
